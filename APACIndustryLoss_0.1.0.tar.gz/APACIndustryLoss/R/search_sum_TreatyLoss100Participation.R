# Function to search for the sum of TreatyLoss100Participation based on EventID and ModelCode
search_sum_TreatyLoss100Participation <- function(event_id, model_code, insured_csv, insurable_csv, output_xlsx) {
  # Read data from CSV files
  insured <- read_csv(insured_csv)
  insurable <- read_csv(insurable_csv)

  # Filter data for Insured and Insurable based on EventID and ModelCode
  insured_match <- filter(insured, EventID == event_id, ModelCode == model_code)
  insurable_match <- filter(insurable, EventID == event_id, ModelCode == model_code)

  # Check if matches are found
  if (nrow(insured_match) == 0 | nrow(insurable_match) == 0) {
    cat("No matches found for EventID", event_id, "with ModelCode", model_code, "\n")
    return(NULL)
  }

  # Extract TreatyLoss100Participation values and calculate sum
  insured_sum <- sum(insured_match$TreatyLoss100Participation)
  insurable_sum <- sum(insurable_match$TreatyLoss100Participation)

  # Extract CountryCode
  insured_country_code <- unique(insured_match$CountryCode)

  # Print sum of TreatyLoss100Participation
  cat("Sum of TreatyLoss100Participation for EventID", event_id, "with ModelCode", model_code, " (Insured): ", insured_sum, "\n")
  cat("Sum of TreatyLoss100Participation for EventID", event_id, "with ModelCode", model_code, " (Insurable): ", insurable_sum, "\n")
  cat("CountryCode for EventID", event_id, "with ModelCode", model_code, " (Insured): ", insured_country_code, "\n")

  # Create a data frame for the result
  result <- data.frame(EventID = event_id,
                       ModelCode = model_code,
                       InsuredLoss = insured_sum,
                       InsurableLoss = insurable_sum,
                       CountryCode = insured_country_code)

  # Write result to CSV file
  if (!file.exists(output_csv)) {
    write.csv(result, file = output_csv, row.names = FALSE)
  } else {
    write.table(result, file = output_csv, append = TRUE, sep = ",", col.names = !file.exists(output_csv), row.names = FALSE)
  }

  cat("Results saved to:", output_csv, "\n")
}

# Provide the file paths for insured.csv, insurable.csv, and output CSV
insured_csv <- "C:/Users/i42743/OneDrive - Verisk Analytics/Desktop/Case_Projects/IndustryLossNumbers/Tool/APAC_Insured_ELT.csv"
insurable_csv <- "C:/Users/i42743/OneDrive - Verisk Analytics/Desktop/Case_Projects/IndustryLossNumbers/Tool/APAC_Insurable_ELT.csv"
output_csv <- "C:/Users/i42743/OneDrive - Verisk Analytics/Desktop/Case_Projects/IndustryLossNumbers/Tool/output.csv"

# Example usage: search for sum of TreatyLoss100Participation for EventID 1624482 with ModelCode 44
search_sum_TreatyLoss100Participation(1624482, 44, insured_csv, insurable_csv, output_csv)
#search_sum_TreatyLoss100Participation(267483, 18, insured_csv, insurable_csv, output_csv)
#search_sum_TreatyLoss100Participation(1624482, 44, insured_csv, insurable_csv, output_csv)
#search_sum_TreatyLoss100Participation(1624482, 44, insured_csv, insurable_csv, output_csv)
#search_sum_TreatyLoss100Participation(1624482, 44, insured_csv, insurable_csv, output_csv)

# Open the exported CSV file
browseURL(output_csv)
